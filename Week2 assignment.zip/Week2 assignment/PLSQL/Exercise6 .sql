-- Generate monthly statements for all customers

DECLARE
    CURSOR GenerateMonthlyStatements IS
        SELECT customer_id, transaction_date, amount, description
        FROM transactions
        WHERE EXTRACT(MONTH FROM transaction_date) = EXTRACT(MONTH FROM SYSDATE)
          AND EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM SYSDATE);
    
    customer_id NUMBER;
    transaction_date DATE;
    amount NUMBER;
    description VARCHAR2(100);
BEGIN
    OPEN GenerateMonthlyStatements;
    LOOP
        FETCH GenerateMonthlyStatements INTO customer_id, transaction_date, amount, description;
        EXIT WHEN GenerateMonthlyStatements%NOTFOUND;
        
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || customer_id);
        DBMS_OUTPUT.PUT_LINE('Date: ' || transaction_date);
        DBMS_OUTPUT.PUT_LINE('Amount: ' || amount);
        DBMS_OUTPUT.PUT_LINE('Description: ' || description);
        DBMS_OUTPUT.PUT_LINE('-------------------------------');
    END LOOP;
    CLOSE GenerateMonthlyStatements;
END;
/


--Apply annual fee to all accounts

DECLARE
    CURSOR ApplyAnnualFee IS
        SELECT account_id, balance
        FROM accounts;
    
    account_id NUMBER;
    balance NUMBER;
    annual_fee CONSTANT NUMBER := 50;  -- Example annual fee amount
BEGIN
    OPEN ApplyAnnualFee;
    LOOP
        FETCH ApplyAnnualFee INTO account_id, balance;
        EXIT WHEN ApplyAnnualFee%NOTFOUND;
        
        UPDATE accounts
        SET balance = balance - annual_fee
        WHERE account_id = account_id;
        
        DBMS_OUTPUT.PUT_LINE('Applied annual fee to Account ID: ' || account_id || '. New balance: ' || (balance - annual_fee));
    END LOOP;
    CLOSE ApplyAnnualFee;
    
    COMMIT;
END;
/

--Update the interest rate for all loans based on a new policy


DECLARE
    CURSOR UpdateLoanInterestRates IS
        SELECT loan_id, interest_rate
        FROM loans;
    
    loan_id NUMBER;
    interest_rate NUMBER;
    new_interest_rate NUMBER;
    
    PROCEDURE CalculateNewInterestRate(old_rate IN NUMBER, new_rate OUT NUMBER) IS
    BEGIN
        -- Example policy: increase interest rate by 1%
        new_rate := old_rate + 1;
    END CalculateNewInterestRate;
    
BEGIN
    OPEN UpdateLoanInterestRates;
    LOOP
        FETCH UpdateLoanInterestRates INTO loan_id, interest_rate;
        EXIT WHEN UpdateLoanInterestRates%NOTFOUND;
        
        CalculateNewInterestRate(interest_rate, new_interest_rate);
        
        UPDATE loans
        SET interest_rate = new_interest_rate
        WHERE loan_id = loan_id;
        
        DBMS_OUTPUT.PUT_LINE('Updated Loan ID: ' || loan_id || ' with new interest rate: ' || new_interest_rate);
    END LOOP;
    CLOSE UpdateLoanInterestRates;
    
    COMMIT;
END;
/
