--  Customer Management Package

-- CustomerManagement Package Specification
CREATE OR REPLACE PACKAGE CustomerManagement IS
    PROCEDURE AddCustomer(p_customer_id IN NUMBER, p_name IN VARCHAR2, p_address IN VARCHAR2);
    PROCEDURE UpdateCustomer(p_customer_id IN NUMBER, p_name IN VARCHAR2, p_address IN VARCHAR2);
    FUNCTION GetCustomerBalance(p_customer_id IN NUMBER) RETURN NUMBER;
END CustomerManagement;
/

-- CustomerManagement Package Body
CREATE OR REPLACE PACKAGE BODY CustomerManagement IS
    PROCEDURE AddCustomer(p_customer_id IN NUMBER, p_name IN VARCHAR2, p_address IN VARCHAR2) IS
    BEGIN
        INSERT INTO customers (customer_id, name, address)
        VALUES (p_customer_id, p_name, p_address);
    END AddCustomer;

    PROCEDURE UpdateCustomer(p_customer_id IN NUMBER, p_name IN VARCHAR2, p_address IN VARCHAR2) IS
    BEGIN
        UPDATE customers
        SET name = p_name, address = p_address
        WHERE customer_id = p_customer_id;
    END UpdateCustomer;

    FUNCTION GetCustomerBalance(p_customer_id IN NUMBER) RETURN NUMBER IS
        v_balance NUMBER;
    BEGIN
        SELECT SUM(balance) INTO v_balance
        FROM accounts
        WHERE customer_id = p_customer_id;
        RETURN v_balance;
    END GetCustomerBalance;
END CustomerManagement;
/

--  Employee Management Package

-- EmployeeManagement Package Specification
CREATE OR REPLACE PACKAGE EmployeeManagement IS
    PROCEDURE HireEmployee(p_employee_id IN NUMBER, p_name IN VARCHAR2, p_position IN VARCHAR2, p_salary IN NUMBER);
    PROCEDURE UpdateEmployee(p_employee_id IN NUMBER, p_name IN VARCHAR2, p_position IN VARCHAR2, p_salary IN NUMBER);
    FUNCTION CalculateAnnualSalary(p_employee_id IN NUMBER) RETURN NUMBER;
END EmployeeManagement;
/

-- EmployeeManagement Package Body
CREATE OR REPLACE PACKAGE BODY EmployeeManagement IS
    PROCEDURE HireEmployee(p_employee_id IN NUMBER, p_name IN VARCHAR2, p_position IN VARCHAR2, p_salary IN NUMBER) IS
    BEGIN
        INSERT INTO employees (employee_id, name, position, salary)
        VALUES (p_employee_id, p_name, p_position, p_salary);
    END HireEmployee;

    PROCEDURE UpdateEmployee(p_employee_id IN NUMBER, p_name IN VARCHAR2, p_position IN VARCHAR2, p_salary IN NUMBER) IS
    BEGIN
        UPDATE employees
        SET name = p_name, position = p_position, salary = p_salary
        WHERE employee_id = p_employee_id;
    END UpdateEmployee;

    FUNCTION CalculateAnnualSalary(p_employee_id IN NUMBER) RETURN NUMBER IS
        v_salary NUMBER;
    BEGIN
        SELECT salary INTO v_salary
        FROM employees
        WHERE employee_id = p_employee_id;
        RETURN v_salary * 12;  -- Assuming salary is monthly
    END CalculateAnnualSalary;
END EmployeeManagement;
/


-- AccountOperations Package Specification
CREATE OR REPLACE PACKAGE AccountOperations IS
    PROCEDURE OpenAccount(p_account_id IN NUMBER, p_customer_id IN NUMBER, p_balance IN NUMBER);
    PROCEDURE CloseAccount(p_account_id IN NUMBER);
    FUNCTION GetTotalBalance(p_customer_id IN NUMBER) RETURN NUMBER;
END AccountOperations;
/

-- AccountOperations Package Body
CREATE OR REPLACE PACKAGE BODY AccountOperations IS
    PROCEDURE OpenAccount(p_account_id IN NUMBER, p_customer_id IN NUMBER, p_balance IN NUMBER) IS
    BEGIN
        INSERT INTO accounts (account_id, customer_id, balance)
        VALUES (p_account_id, p_customer_id, p_balance);
    END OpenAccount;

    PROCEDURE CloseAccount(p_account_id IN NUMBER) IS
    BEGIN
        DELETE FROM accounts
        WHERE account_id = p_account_id;
    END CloseAccount;

    FUNCTION GetTotalBalance(p_customer_id IN NUMBER) RETURN NUMBER IS
        v_total_balance NUMBER;
    BEGIN
        SELECT SUM(balance) INTO v_total_balance
        FROM accounts
        WHERE customer_id = p_customer_id;
        RETURN v_total_balance;
    END GetTotalBalance;
END AccountOperations;
/

			