--  Process monthly interest for all savings accounts

CREATE PROCEDURE ProcessMonthlyInterest
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Apply 1% interest to all savings accounts
        UPDATE Accounts
        SET Balance = Balance * 1.01
        WHERE AccountType = 'Savings';

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;

        -- Log error message
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO

--  Update employee bonus based on their performance

CREATE PROCEDURE UpdateEmployeeBonus(
    @DepartmentId INT,
    @BonusPercentage DECIMAL(5, 2)
)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Update the salary of employees in the given department by adding a bonus percentage
        UPDATE Employees
        SET Salary = Salary * (1 + @BonusPercentage / 100)
        WHERE DepartmentId = @DepartmentId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;

        -- Log error message
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO

--  Transfer funds between customer accounts

CREATE PROCEDURE TransferFunds(
    @SourceAccountId INT,
    @DestinationAccountId INT,
    @Amount DECIMAL(18, 2)
)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Check if the source account has sufficient funds
        DECLARE @SourceBalance DECIMAL(18, 2);
        SELECT @SourceBalance = Balance FROM Accounts WHERE AccountId = @SourceAccountId;

        IF @SourceBalance < @Amount
        BEGIN
            RAISERROR('Insufficient funds in source account.', 16, 1);
        END

        -- Deduct amount from the source account
        UPDATE Accounts
        SET Balance = Balance - @Amount
        WHERE AccountId = @SourceAccountId;

        -- Add amount to the destination account
        UPDATE Accounts
        SET Balance = Balance + @Amount
        WHERE AccountId = @DestinationAccountId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;

        -- Log error message
