--Applying a Discount to Loan Interest Rates for Customers Above 60

DECLARE
    CURSOR c_customers IS
        SELECT customer_id, age, loan_interest_rate
        FROM customers
        WHERE age > 60;
    
    v_customer_id customers.customer_id%TYPE;
    v_age customers.age%TYPE;
    v_loan_interest_rate customers.loan_interest_rate%TYPE;
BEGIN
    OPEN c_customers;
    LOOP
        FETCH c_customers INTO v_customer_id, v_age, v_loan_interest_rate;
        EXIT WHEN c_customers%NOTFOUND;
        
        -- Apply a 1% discount to the loan interest rate
        UPDATE customers
        SET loan_interest_rate = v_loan_interest_rate * 0.99
        WHERE customer_id = v_customer_id;
    END LOOP;
    CLOSE c_customers;
    
    COMMIT;
END;
/

-- Promoting Customers to VIP Status Based on Their Balance


DECLARE
    CURSOR c_customers IS
        SELECT customer_id, balance
        FROM customers
        WHERE balance > 10000;
    
    v_customer_id customers.customer_id%TYPE;
    v_balance customers.balance%TYPE;
BEGIN
    OPEN c_customers;
    LOOP
        FETCH c_customers INTO v_customer_id, v_balance;
        EXIT WHEN c_customers%NOTFOUND;
        
        -- Set IsVIP flag to TRUE
        UPDATE customers
        SET IsVIP = TRUE
        WHERE customer_id = v_customer_id;
    END LOOP;
    CLOSE c_customers;
    
    COMMIT;
END;
/

-- Sending Reminders for Loans Due Within the Next 30 Days

DECLARE
    CURSOR c_loans IS
        SELECT customer_id, loan_due_date
        FROM loans
        WHERE loan_due_date BETWEEN SYSDATE AND SYSDATE + 30;
    
    v_customer_id loans.customer_id%TYPE;
    v_loan_due_date loans.loan_due_date%TYPE;
BEGIN
    OPEN c_loans;
    LOOP
        FETCH c_loans INTO v_customer_id, v_loan_due_date;
        EXIT WHEN c_loans%NOTFOUND;
        
        -- Print reminder message
        DBMS_OUTPUT.PUT_LINE('Reminder: Customer ID ' || v_customer_id || ' has a loan due on ' || v_loan_due_date);
    END LOOP;
    CLOSE c_loans;
END;
/
