--  Automatically update the last modified date when a customer's record is updated

CREATE TRIGGER UpdateCustomerLastModified
ON Customers
AFTER UPDATE
AS
BEGIN
    UPDATE Customers
    SET LastModified = GETDATE()
    FROM Inserted
    WHERE Customers.CustomerId = Inserted.CustomerId;
END;
GO

--  Maintain an audit log for all transactions

CREATE TRIGGER LogTransaction
ON Transactions
AFTER INSERT
AS
BEGIN
    INSERT INTO AuditLog (TransactionId, AccountId, Amount, TransactionDate, Operation)
    SELECT 
        Inserted.TransactionId, 
        Inserted.AccountId, 
        Inserted.Amount, 
        GETDATE(), 
        'INSERT'
    FROM Inserted;
END;
GO

--  Enforce business rules on deposits and withdrawals

CREATE TRIGGER CheckTransactionRules
ON Transactions
INSTEAD OF INSERT
AS
BEGIN
    DECLARE @AccountId INT;
    DECLARE @Amount DECIMAL(18, 2);
    DECLARE @Balance DECIMAL(18, 2);

    SELECT @AccountId = AccountId, @Amount = Amount
    FROM Inserted;

    -- Check if the transaction amount is positive for deposits
    IF @Amount < 0
    BEGIN
        -- Check if there are sufficient funds for withdrawals
        SELECT @Balance = Balance FROM Accounts WHERE AccountId = @AccountId;

        IF @Balance < ABS(@Amount)
        BEGIN
            RAISERROR('Insufficient funds for withdrawal.', 16, 1);
            RETURN;
        END
    END
    ELSE IF @Amount = 0
    BEGIN
        RAISERROR('Transaction amount must be positive.', 16, 1);
        RETURN;
    END

    -- Insert the transaction if all checks pass
    INSERT INTO Transactions (AccountId, Amount, TransactionDate)
    SELECT AccountId, Amount, TransactionDate
    FROM Inserted;
END;
GO
