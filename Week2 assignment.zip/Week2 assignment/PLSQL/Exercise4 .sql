--  Calculate the age of customers for eligibility checks

CREATE FUNCTION CalculateAge (@DateOfBirth DATE)
RETURNS INT
AS
BEGIN
    DECLARE @Age INT;
    SET @Age = DATEDIFF(YEAR, @DateOfBirth, GETDATE()) - 
               CASE 
                   WHEN MONTH(@DateOfBirth) > MONTH(GETDATE()) OR 
                        (MONTH(@DateOfBirth) = MONTH(GETDATE()) AND DAY(@DateOfBirth) > DAY(GETDATE())) 
                   THEN 1 
                   ELSE 0 
               END;
    RETURN @Age;
END;
GO

--  Compute the monthly installment for a loan

CREATE FUNCTION CalculateMonthlyInstallment (
    @LoanAmount DECIMAL(18, 2),
    @AnnualInterestRate DECIMAL(5, 2),
    @LoanDurationYears INT
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @MonthlyInterestRate DECIMAL(5, 4);
    DECLARE @NumberOfPayments INT;
    DECLARE @MonthlyInstallment DECIMAL(18, 2);

    SET @MonthlyInterestRate = @AnnualInterestRate / 12 / 100;
    SET @NumberOfPayments = @LoanDurationYears * 12;

    SET @MonthlyInstallment = @LoanAmount * @MonthlyInterestRate / 
                              (1 - POWER(1 + @MonthlyInterestRate, -@NumberOfPayments));
    RETURN @MonthlyInstallment;
END;
GO

--  Check if a customer has sufficient balance before making a transaction

CREATE FUNCTION HasSufficientBalance (
    @AccountId INT,
    @Amount DECIMAL(18, 2)
)
RETURNS BIT
AS
BEGIN
    DECLARE @Balance DECIMAL(18, 2);

    SELECT @Balance = Balance FROM Accounts WHERE AccountId = @AccountId;

    IF @Balance >= @Amount
        RETURN 1;
    ELSE
        RETURN 0;
END;
GO
