--  Handle exceptions during fund transfers between accounts

CREATE PROCEDURE SafeTransferFunds(
    @SourceAccountId INT,
    @DestinationAccountId INT,
    @Amount DECIMAL(18, 2)
)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Check if the source account has sufficient funds
        DECLARE @SourceBalance DECIMAL(18, 2);
        SELECT @SourceBalance = Balance FROM Accounts WHERE AccountId = @SourceAccountId;
        
        IF @SourceBalance < @Amount
        BEGIN
            RAISERROR('Insufficient funds in source account.', 16, 1);
        END
        
        -- Deduct amount from the source account
        UPDATE Accounts
        SET Balance = Balance - @Amount
        WHERE AccountId = @SourceAccountId;
        
        -- Add amount to the destination account
        UPDATE Accounts
        SET Balance = Balance + @Amount
        WHERE AccountId = @DestinationAccountId;
        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        -- Log error message
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;
        
        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO

--  Manage errors when updating employee salaries

CREATE PROCEDURE UpdateSalary(
    @EmployeeId INT,
    @PercentageIncrease DECIMAL(5, 2)
)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Check if the employee exists
        IF NOT EXISTS (SELECT 1 FROM Employees WHERE EmployeeId = @EmployeeId)
        BEGIN
            RAISERROR('Employee ID does not exist.', 16, 1);
        END
        
        -- Update the salary
        UPDATE Employees
        SET Salary = Salary * (1 + @PercentageIncrease / 100)
        WHERE EmployeeId = @EmployeeId;
        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        -- Log error message
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;
        
        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO

-- Ensure data integrity when adding a new customer

CREATE PROCEDURE AddNewCustomer(
    @CustomerId INT,
    @CustomerName NVARCHAR(100),
    @CustomerAddress NVARCHAR(200)
)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- Check if a customer with the same ID already exists
        IF EXISTS (SELECT 1 FROM Customers WHERE CustomerId = @CustomerId)
        BEGIN
            RAISERROR('Customer ID already exists.', 16, 1);
        END
        
        -- Insert new customer
        INSERT INTO Customers (CustomerId, CustomerName, CustomerAddress)
        VALUES (@CustomerId, @CustomerName, @CustomerAddress);
        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        -- Log error message
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;
        
        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();
        
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO
